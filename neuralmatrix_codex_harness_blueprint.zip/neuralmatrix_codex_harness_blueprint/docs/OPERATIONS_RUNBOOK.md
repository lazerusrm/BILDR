# Harness Console Linux Operations Runbook

**Status:** initial operating specification  
**Deployment:** single-user, local-first, `systemd --user`

## 1. Runtime prerequisites

Required on the Linux host:

- a supported `codex` CLI installation authenticated through the user's normal Codex mechanism;
- Git 2.40 or newer recommended;
- the NeuralMatrix repository cloned locally with a configured owner Git identity;
- Rust toolchain for building Harness Console;
- a Node.js toolchain only while building the embedded frontend;
- `rg`, `bash`, and repository-specific build prerequisites;
- `gh` for later draft-PR/CI integration;
- Docker or Podman for NeuralMatrix containerized C2/cross-build lanes;
- configured access to required hardware/runner targets where applicable.

Missing optional heavy/hardware prerequisites are shown as unavailable. They never become a passing validation.

## 2. XDG paths

Defaults:

```text
$XDG_CONFIG_HOME/harness-console/config.toml
$XDG_CONFIG_HOME/harness-console/profiles/
$XDG_DATA_HOME/harness-console/harness.sqlite3
$XDG_DATA_HOME/harness-console/artifacts/sha256/
$XDG_DATA_HOME/harness-console/worktrees/<repo>/<run>/<task>/
$XDG_CACHE_HOME/harness-console/repo-index/
$XDG_STATE_HOME/harness-console/logs/
```

Fallbacks use `~/.config`, `~/.local/share`, `~/.cache`, and `~/.local/state` according to the Linux XDG base-directory convention.

Use a filesystem with adequate inode capacity and free space. NeuralMatrix is large and build caches/worktrees can dominate disk use even though Git objects are shared.

## 3. Installation flow

Development build:

```bash
cargo xtask ui-build
cargo build --release -p harnessd -p harnessctl
install -Dm755 target/release/harnessd "$HOME/.local/bin/harnessd"
install -Dm755 target/release/harnessctl "$HOME/.local/bin/harnessctl"
install -Dm644 packaging/systemd/harnessd.service \
  "$HOME/.config/systemd/user/harnessd.service"
mkdir -p "$HOME/.config/harness-console"
cp config/harness.example.toml "$HOME/.config/harness-console/config.toml"
systemctl --user daemon-reload
systemctl --user enable --now harnessd.service
```

The release pipeline should produce a checksummed tarball containing the static Rust binaries, embedded UI, default schemas/profiles, systemd unit, license, and release manifest.

## 4. First startup checks

```bash
systemctl --user status harnessd.service
journalctl --user -u harnessd.service -n 200 --no-pager
harnessctl doctor
harnessctl runtime codex
```

`doctor` verifies:

- XDG directories and permissions;
- SQLite migration/open/WAL;
- free disk space;
- `codex` binary/version/auth readiness;
- generated protocol-schema match;
- Git/`rg`/shell prerequisites;
- browser endpoint on localhost;
- profile parsing;
- no unsafe non-loopback bind;
- optional `gh`, Docker/Podman, Rust, and NeuralMatrix-specific prerequisites.

## 5. Register NeuralMatrix

```bash
harnessctl repo add \
  --profile neuralmatrix \
  --path /path/to/NeuralMatrix

harnessctl repo inspect neuralmatrix
```

Registration fails closed when:

- the path is not a Git repository;
- the configured remote does not match policy without explicit override;
- the primary checkout is dirty;
- the primary checkout is not on the expected coordination branch where the profile requires it;
- an existing managed worktree root conflicts;
- mandatory instruction/authority files are absent;
- Git identity is missing;
- filesystem permissions do not permit managed worktrees.

The repository can remain registered while temporarily dirty, but new mutable runs are blocked until clean.

## 6. Start a run

From the GUI or:

```bash
harnessctl run create \
  --repo neuralmatrix \
  --base origin/main \
  --mode plan-and-implement \
  --objective-file ./objective.md
```

Run preparation:

1. acquire repository coordination lock;
2. verify primary checkout clean;
3. `git fetch --prune origin` through the controller-owned network path;
4. resolve and persist exact base SHA;
5. create a read-only inspection worktree;
6. load/hash instruction and authority sources;
7. build or refresh the bounded repository index;
8. start the Sol architect thread;
9. wait for a schema-valid task graph;
10. present plan review when policy requires it.

## 7. Normal operation

Use the browser at the configured localhost address. The service may open it automatically.

Daily checks:

```bash
harnessctl status
harnessctl approvals list
harnessctl worktree list --stale
harnessctl storage report
```

The daemon continuously checks:

- App Server liveness;
- protocol projection lag;
- agent heartbeat/lease TTL;
- command process state;
- worktree branch/head/status;
- primary checkout cleanliness;
- disk thresholds;
- SQLite WAL growth;
- event-stream subscribers;
- resource queue capacity.

## 8. Pausing and shutdown

Graceful service stop:

```bash
harnessctl scheduler pause
harnessctl run stop-after-current <run-id>
systemctl --user stop harnessd.service
```

On SIGTERM, `harnessd`:

1. stops dispatching new tasks/turns;
2. requests active turns to interrupt only when shutdown timeout requires it;
3. waits for controller-owned commands to reach a safe boundary;
4. checkpoints SQLite/WAL;
5. records active worktree/agent state;
6. terminates App Server;
7. exits.

A daemon restart must preserve and reconcile runs; it must not abandon or silently delete worktrees.

## 9. App Server incident

Symptoms: runtime badge red, agent streams stop, new turns disabled.

```bash
harnessctl runtime codex inspect
journalctl --user -u harnessd.service --since -30m
harnessctl runtime codex restart
```

Do not force-restart repeatedly when the schema mismatches. Install/select the pinned Codex version or deliberately update the generated schema and adapter through the compatibility test suite.

After recovery, inspect any task whose command may have continued through the lost protocol session. Such a task needs reconciliation and usually independent verification before acceptance.

## 10. Stalled agent or expired lease

First timeout:

- controller sends a bounded request: return patch, blocker, or `needs_help` handoff;
- UI marks lease warning;
- no new overlapping task can acquire the paths.

Second timeout:

- interrupt turn;
- preserve worktree and logs;
- close attempt as `STALLED`;
- release lease only after process and diff reconciliation;
- start a fresh attempt or escalate with the prior evidence.

Never reuse the same mutable worktree concurrently for two agent sessions.

## 11. Worktree recovery

```bash
harnessctl worktree inspect <worktree-id>
harnessctl worktree preserve <worktree-id>
harnessctl worktree open-shell <worktree-id>
harnessctl worktree cleanup <worktree-id> --dry-run
```

Cleanup preconditions:

- no live agent/process uses it;
- no active lease;
- branch/head/diff captured;
- committed work is pushed or explicitly declared disposable by the user;
- uncommitted changes are archived or explicitly discarded;
- related evidence references are durable.

After removal, run `git worktree prune` through the locked repository manager.

## 12. Disk pressure

Threshold policy example:

```text
warning:       less than 15% or 100 GB free
critical:      less than 8% or 40 GB free
execution stop less than 5% or 20 GB free
```

At critical, stop dispatching heavy builds and new worktrees. Offer dry-run cleanup categories:

- expired raw event bundles;
- compressed command logs past retention;
- removable completed worktrees;
- Harness-owned temporary files;
- explicitly configured repository build caches.

Never run global Docker image/volume pruning automatically. NeuralMatrix cleanup scripts may have broader host scope and require explicit operator approval.

## 13. Database maintenance

```bash
harnessctl db check
harnessctl db backup --out /safe/path/harness-$(date +%F).sqlite3
harnessctl db vacuum --dry-run
harnessctl projections rebuild --from 0
```

Backups use SQLite's online backup API or a checkpointed consistent copy. Artifact manifests and config/profile versions should be backed up with the database.

Raw-event projection can be rebuilt. Human decisions, cost entries, and evidence manifests remain normal durable tables and are included in backup.

## 14. Upgrade

1. pause scheduling;
2. ensure no mutable commands are active;
3. backup DB/config/profile;
4. install new binaries/assets;
5. run `harnessctl migrate --check`;
6. validate Codex version/schema compatibility;
7. restart service;
8. run replay/golden adapter smoke;
9. resume scheduling.

A migration is forward-only in production. Test downgrade by restoring the pre-upgrade backup, not by attempting reverse SQL against live data.

## 15. Codex version upgrade procedure

1. install candidate CLI alongside or in a test environment;
2. generate JSON Schema and TypeScript bindings;
3. compare schema to the pinned version;
4. add/update sanitized golden event traces;
5. update Rust adapter and unknown-event handling;
6. run adapter unit/replay tests;
7. run fake App Server failure suite;
8. run one read-only NeuralMatrix architecture smoke;
9. run one bounded docs-only mutable smoke;
10. update `required_version` and schema digest;
11. release Harness Console with the new compatibility tuple.

Do not change the required Codex version independently on a production host and hope the protocol remains compatible.

## 16. Security incident

Potential secret exposure:

1. pause scheduling and network-enabled operations;
2. preserve raw evidence with restricted permissions;
3. identify command/event/artifact and affected credential;
4. revoke/rotate credential through its owner system;
5. add redaction detector/regression;
6. verify no secret entered Git history, PR, or shared evidence;
7. document incident locally and resume only after review.

The harness is not a secrets vault. Do not add general credential storage to solve this class of problem.

## 17. Export and archive

```bash
harnessctl run export <run-id> --format bundle --out ./run-bundle.tar.zst
harnessctl evidence verify ./run-bundle.tar.zst
```

Bundle contents:

- run/task/handoff manifests;
- exact base/integration/task SHAs;
- authority/profile/schema/pricing digests;
- sanitized activity and decisions;
- diffs/commits;
- command/validation summaries and selected full artifacts;
- findings/verdicts;
- cost ledger;
- proof limits;
- artifact hash manifest.

Raw private reasoning is absent by default. Secrets are not intentionally included. The verifier checks every content hash and referential link.

## 18. Remote access

The supported remote path is an SSH tunnel to the local-only listener:

```bash
ssh -L 7310:127.0.0.1:7310 user@linux-host
```

Do not bind the UI or App Server directly to a LAN/WAN interface in v1. Multi-user authentication, TLS termination, and remote authorization are explicitly outside the initial product boundary.

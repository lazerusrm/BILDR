# Harness Console Blueprint

**Status:** proposed implementation blueprint  
**Initial repository profile:** `lazerusrm/NeuralMatrix`  
**Target platform:** Linux, local-first  
**Prepared:** 2026-08-05

Harness Console is a Linux-first supervisory control plane for Codex agents. It preserves Codex's local execution, sandbox, worktree, thread, approval, review, goal, usage, and subagent behavior while adding deterministic orchestration, durable run state, exact Git custody, evidence, API-equivalent cost telemetry, and a focused multi-agent GUI.

This package is a build specification, not a finished application.

## Recommended product shape

- `harnessd`: one Rust daemon, managed by `systemd --user`.
- `harnessctl`: operator CLI using the same domain/API path as the GUI.
- Browser/PWA UI served from the daemon on `127.0.0.1`.
- One version-pinned `codex app-server` child process over JSONL stdio.
- SQLite/WAL raw event journal plus relational projections.
- Content-addressed artifact/evidence storage.
- Controller-created top-level Codex threads for mutable tasks, one Git worktree per task attempt.
- Codex-native subagents primarily for read-only exploration, testing/log analysis, and review inside a task.
- NeuralMatrix repository profile that imports existing authority, task, proof, and merge rules rather than replacing them.
- Explicit human approval for push/draft PR; no automatic merge.

## Start here

1. `ARCHITECTURE_AND_IMPLEMENTATION_PLAN.md` — complete product/system tape-out.
2. `docs/UI_WIREFRAMES.md` — screen architecture, controls, and UX acceptance.
3. `docs/IMPLEMENTATION_BACKLOG.md` — HC-001 through HC-023 dependency-ordered PR train.
4. `docs/APP_SERVER_EVENT_MAPPING.md` — protocol adapter and recovery contract.
5. `docs/TEST_AND_ACCEPTANCE_PLAN.md` — unit/integration/fault/pilot/release gates.
6. `docs/OPERATIONS_RUNBOOK.md` — install, register, operate, recover, upgrade, and export.
7. `docs/COST_ACCOUNTING.md` — token and API-equivalent cost ledger.

## Supporting implementation artifacts

- `adrs/` — fixed v1 architectural decisions.
- `config/harness.example.toml` — daemon, runtime, security, retention, and price configuration.
- `profiles/neuralmatrix/profile.toml` — initial NeuralMatrix policy/model/path/validator profile.
- `schemas/*.schema.json` — task, handoff, and evidence contracts.
- `migrations/0001_initial.sql` — durable state/event/evidence schema.
- `openapi/harness-api.yaml` — local REST/SSE API contract.
- `codex/agents/*.toml` — proposed custom agent roles.
- `codex/skills/` — bounded probe and NeuralMatrix task execution guidance.
- `examples/` — schema-valid objective, task, handoff, and evidence examples.
- `mockups/run-workspace.html` — self-contained interactive visual mockup of the primary GUI.
- `packaging/systemd/harnessd.service` — initial Linux user-service unit.

## Build order

1. Implement configuration/XDG/storage and App Server supervisor.
2. Render one durable read-only Codex thread in the GUI.
3. Add repository registration, worktree ownership, path leases, approvals, commands, and diff custody.
4. Add task state/DAG, token/cost accounting, and evidence.
5. Add bounded scheduling, independent verification, serial integration, and recovery.
6. Add the NeuralMatrix profile/context compiler/validators.
7. Add explicit draft-PR publication, packaging, and the NeuralMatrix pilot campaign.

Do not enable parallel mutable agents before one task can be interrupted, recovered, diffed, independently verified, and costed correctly.
